// Do What The Fuck you Want to Public License 2 (WTFPL)
