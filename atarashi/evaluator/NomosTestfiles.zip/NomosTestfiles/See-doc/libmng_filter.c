/* ************************************************************************** */
/* * For conditions of distribution and use, * */
/* * see copyright notice in libmng.h * */
/* ************************************************************************** */
/* * * */
/* * project : libmng * */
/* * file : libmng_filter.c copyright (c) 2000-2004 G.Juyn * */
/* * version : 1.0.9 * */
/* * * */