/*
*
* Cross-platform basename/dirname
*
* Copyright 2005 Syd Logan, All Rights Reserved
*
* This code is distributed without warranty. You are free to use this
* code for any purpose, however, if this code is republished or
* redistributed in its original form, as hardcopy or electronically,
* then you must include this copyright notice along with the code.
*
*/
