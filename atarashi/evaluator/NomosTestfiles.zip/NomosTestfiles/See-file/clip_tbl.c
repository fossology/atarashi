/*
* This file is part of the Chelsio T4 Ethernet driver for Linux.
* Copyright (C) 2003-2014 Chelsio Communications. All rights reserved.
*
* Written by Deepak (deepak.s@chelsio.com)
*
* This program is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE. See the LICENSE file included in this
* release for licensing terms and conditions.
*/
