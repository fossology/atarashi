/*
 * Include file for ecurses, the eiffel library to (N)Curses
 *
 * Released under the Eiffel Forum Licence, or the LGPL
 *
 * Author : Paul G. Crismer (pgcrism @ users . sourceforge . net)
 *
 * $Version: $
 * $Date$
 *
*/
#include <panel.h>

